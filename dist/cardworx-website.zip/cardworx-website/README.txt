CARDWORX WEBSITE - HOSTING FILES
=================================
This folder is the complete, ready-to-serve website. No build step, no database,
no server-side code. Upload the CONTENTS of this folder (not the folder itself)
to the web root of the hosting account.

GoDaddy (cPanel / Web Hosting)
  1. Hosting dashboard -> cPanel -> File Manager -> public_html
  2. Delete any placeholder files in public_html (default.html, coming soon page)
  3. Upload every file and the "assets" folder from this zip into public_html
     (Upload the zip and use "Extract" in File Manager to save time.)
  4. index.html must sit directly in public_html.
  5. Visit the domain. Hard refresh (Cmd/Ctrl + Shift + R) if the old site shows.

GoDaddy Website Builder (not cPanel) cannot host custom HTML. If the account is
Website Builder only, add a "Web Hosting" plan or point the domain at the free
GitHub Pages copy instead: https://craftmaster7.github.io/cardworx/

What is in here
  index.html             Home
  dual-pricing.html, card-processing.html, crypto-payments.html,
  customer-financing.html, business-funding.html, high-risk.html   Solutions pages
  industries.html, terminals.html, savings.html, agents.html, financing.html, faq.html
  portal.html + portal-config.js      Agent portal (invite only; backend is Supabase)
  assets/                Images, video, logos, favicon

After the site is live on cardworxusa.com
  - In Supabase (Authentication -> URL Configuration) change the Site URL and
    Redirect URL from the github.io address to https://www.cardworxusa.com/portal.html
    so agent invite and password reset emails link to the right place.
  - Make sure the site is served over HTTPS (GoDaddy includes a free SSL on most plans).
